<?php
require_once("post.php");

// require_once("commentSection.php");

// echo $commentSection;
class PostWall
{
    protected $userName;
    protected $allMyPosts = array();  
    protected $db;
	protected $displayPreference;
    // protected $targetID;
    
    public function __construct($db, $userName, $preference="root")
    {
        $this->userName = $userName;
        $this->db = $db;
    }
    
    public function displayAllRootPosts()
    {
        $sql = "select * from post where parentID = 0";
		$this->retrieveAllRootPosts($sql);
    }
	
	public function setMyDisplayPreference($preference)
	{
		$this->displayPreference = $preference;
	}
	
	public function displayMyPosts()
	{
		if ($this->displayPreference == "root")
		{
			$this->displayAllRootPosts();
		}
		elseif ($this->displayPreference == "oldest")
		{
			$this->displayPostsByOldest();
		}
		elseif ($this->displayPreference == "recent")
		{
			$this->displayPostsByRecent();
		}
		// elseif ($this->displayPreference == "showOne")
        // {
            // $this->displayTargetpost();
        // }
		return $this->allMyPosts;
	}
    
	public function findMyPost($targetPostID)
	{
		foreach($this->displayMyPosts() as $aPost)
		{
			if ($targetPostID == $aPost->getPostID())
			{
				$targetPost = $aPost;
				return $targetPost;
			}
		}
	}
    
    public function setTargetID($id)
    {
        $this->targetID = $id;
    }
	
	public function displayTargetpost()
	{
		$sql = "select * from post where postID = ". $this->targetID;
		$this->retrieveAllRootPosts($sql);
	}
	
    public function displayPostsByRecent()
    {
		$sql = "select * from post order by date DESC";
		$this->retrieveAllRootPosts($sql);
		
    }
    
    public function displayPostsbyOldest()
    {
		$sql = "select * from post order by date ASC";
		$this->retrieveAllRootPosts($sql);
    }
	
    private function retrieveAllRootPosts($sql)
    {
        $this->allMyPosts = array();
		$post = $this->db->query($sql);
        $result = "";
        while ($aRow = $post->fetch())
        {
            $postID = $aRow['postID'];
            $postTitle = $aRow['postTitle'];
            $userName = $aRow['userName'];
            $content = $aRow['content'];
            $date = $aRow['date'];
            $aPost = new Post($this->db, $userName, $postTitle, $content);
            $aPost->setID($postID);
            $aPost->setDate($date);
            
            $this->allMyPosts[] = $aPost;
        }
    }      
}


?>