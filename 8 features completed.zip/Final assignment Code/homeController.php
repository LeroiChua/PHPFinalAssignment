<?php
session_save_path("./");
session_start();
require_once("MySQLDB.php");
require_once("db.php");
require_once("postwall.php");
// require_once("commentSection.php");

$userName = $_SESSION['userName'];
$postwall = new PostWall($db, $userName);
if (!empty($_SESSION['preference']))
{
	$preference = $_SESSION['preference'];	
    if (! empty($_SESSION['targetID']))
    {
        $targetID = $_SESSION['targetID'];
        $postwall->setTargetID($targetID);
    }
    $postwall->setMyDisplayPreference($preference);
}

if (isset($_POST['preference']))
{
	$preference = $_POST['preference'];
	$_SESSION["preference"] = $preference;
	$postwall->setMyDisplayPreference($preference);
	header('Location: BaghChal_feature.php');
}
else
{
	$preference = "root";
	$postwall->setMyDisplayPreference($preference);
}

if (isset($_POST['postContent']) && isset($_POST['postTitle']) && isset($_POST['parentID']))
{
	$postTitle = $_POST['postTitle'];
    $postContent = $_POST['postContent'];
	$postParentID = $_POST['parentID'];
	$aPost = new Post($db, $userName, $postTitle, $postContent, $postParentID);
	$aPost->createPost($db);
	var_dump($aPost);
	header('Location: BaghChal_feature.php');
}  
else
{
	if (isset($_POST['postContent']) && isset($_POST['postTitle']))
	{
		$postTitle = $_POST['postTitle'];
		$postContent = $_POST['postContent'];
		$aPost = new Post($db, $userName, $postTitle, $postContent);
		$aPost->createPost($db);
		var_dump($aPost);
		header('Location: BaghChal_feature.php');
	} 	
}

if (isset($_POST['editContent']) && isset($_POST['editTitle']) && isset($_POST['targetPostID']))
{
	$postTitle = $_POST['editTitle'];
    $postContent = $_POST['editContent'];
	$targetPostID = $_POST['targetPostID'];
	$targetPost = $postwall->findMyPost($targetPostID);
	
	$targetPost->editPost($postTitle, $postContent);
	header('Location: BaghChal_feature.php');
}  

if (isset($_POST['deletePostID']))
{

	$targetPostID = $_POST['deletePostID'];
	$targetPost = $postwall->findMyPost($targetPostID);
	$targetPost->deletePost();
	header('Location: BaghChal_feature.php');
}  

// if (isset($_POST['showOnePost']))
// {
	// $targetPostID = $_POST['showOnePost'];
	// $preference = "showOne";
	// $_SESSION["preference"] = $preference;
    // $_SESSION["targetID"] = $targetPostID;
	// header('Location: BaghChal_feature.php');
// } 

?>