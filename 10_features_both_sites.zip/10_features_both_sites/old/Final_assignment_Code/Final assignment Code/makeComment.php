<?php
session_save_path("./");
session_start();
require_once("MySQLDB.php");
require_once('db.php');

require_once("comment.php");


?>