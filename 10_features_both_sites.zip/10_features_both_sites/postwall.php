<?php
require_once("post.php");

// require_once("commentSection.php");

// echo $commentSection;
class PostWall
{
    protected $userName;
    protected $allMyPosts = array();
    protected $db;
	protected $displayPreference;
    protected $displayUser;
    protected $searchText;
    // protected $targetID;

    public function __construct($db, $userName, $preference="root")
    {
        $this->userName = $userName;
        $this->db = $db;
    }

	public function setMyDisplayPreference($preference)
	{
		$this->displayPreference = $preference;
	}

    public function setDisplayUser($userName)
    {
        $this->displayUser = $userName;
    }

    public function setSearchText($searchText)
    {
        $this->searchText = $searchText;
    }

    public function getDisplayUser()
    {
        return $this->displayUser;
    }

    public function getSearchText()
    {
        return $this->searchText;
    }

    public function getDisplayPreference()
    {
        return $this->displayPreference;
    }

	public function displayMyPosts()
	{
        $this->displayAllPosts($this->getDisplayUser(), $this->getSearchText(), $this->getDisplayPreference());

		// elseif ($this->displayPreference == "showOne")
        // {
            // $this->displayTargetpost();
        // }
		return $this->allMyPosts;
	}

	public function findMyPost($targetPostID)
	{
		foreach($this->displayMyPosts() as $aPost)
		{
			if ($targetPostID == $aPost->getPostID())
			{
				$targetPost = $aPost;
				return $targetPost;
			}
		}
	}

    public function setTargetID($id)
    {
        $this->targetID = $id;
    }

	public function displayTargetpost()
	{
		$sql = "select * from post where postID = ". $this->targetID;
		$this->retrieveAllRootPosts($sql);
	}


    public function displayAllPosts($user='', $searchText='', $preference='')
    {
        $selectUserPosts="";
        if($user!='')
        {
            $selectUserPosts = " and userName = '$user' ";
        }
        if($searchText!='')
        {
            $selectUserPosts .= " and content like '%".$searchText."%'";
        }
        switch($preference)
        {
            case 'oldest':
                $selectUserPosts .= " order by date ASC";
                break;
            case 'recent':
                $selectUserPosts .= " order by date DESC";
                break;
            case '':
                $selectUserPosts .= "";
                break;
        }
        $sql = "select * from post where parentID = 0".$selectUserPosts;
		$this->retrieveAllRootPosts($sql);

    }


    private function retrieveAllRootPosts($sql)
    {
        $this->allMyPosts = array();
		$post = $this->db->query($sql);
        $result = "";
        while ($aRow = $post->fetch())
        {
            $postID = $aRow['postID'];
            $postTitle = $aRow['postTitle'];
            $userName = $aRow['userName'];
            $content = $aRow['content'];
            $date = $aRow['date'];
            $aPost = new Post($this->db, $userName, $postTitle, $content);
            $aPost->setID($postID);
            $aPost->setDate($date);

            $this->allMyPosts[] = $aPost;
        }
    }

    public function getAllUsers()
	{
		$sql = "select distinct userName from post";
		$users = $this->db->query($sql);
		$result = array();
        while ($aUser = $users->fetch())
        {
            $result[] = $aUser;
        }
        return $result;
	}
}


?>
