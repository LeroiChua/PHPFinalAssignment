<?php

require_once('build.php');

if (isset($_POST['userEmail']) && isset(($_POST['userPassword'])))
{
	$userName = $_POST['userEmail'];
	$password = $_POST['userPassword'];
	$sql = "select * from user where userName = '$userName' and password = '$password'";
	$customer = $db->query($sql);
	$row = $customer->fetch();
	$result = $row['userID'];

	if (!$result)
	{
        $_SESSION['login'] = false;
		$loginPage = $iniArray['pages']['login'];
		header($loginPage);

	}
	else
	{
		//session_save_path('./');
		//session_start();
		$_SESSION['userName'] = $userName;
		$_SESSION['password'] = $password;
		$featurePage = $iniArray['pages']['feature'];
		header($featurePage);
	}

}

?>
