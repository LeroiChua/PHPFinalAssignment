<?php
//session_save_path("./");
//session_start();
require_once("MySQLDB.php");
require_once("db.php");
require_once("postwall.php");
// require_once("commentSection.php");

$userName = $_SESSION['userName'];
$postwall = new PostWall($db, $userName);

if(isset($_GET['preference']))
{
	$preference = $_GET['preference'];
	$_SESSION["preference"] = $preference;
	$postwall->setMyDisplayPreference($preference);
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}
else
{
	$preference = "root";
	$postwall->setMyDisplayPreference($preference);
}

if(isset($_GET['UserList']))
{
	$user = $_GET['UserList'];
	$_SESSION['viewUser'] = $user;
	$postwall->setDisplayUser($user);
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}

if(isset($_GET['searchText']))
{
	$searchText = $_GET['searchText'];
	$_SESSION['searchText'] = $searchText;
	$postwall->setSearchText($searchText);
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}

if (!empty($_SESSION['preference']))
{
	$preference = $_SESSION['preference'];
    if (! empty($_SESSION['targetID']))
    {
        $targetID = $_SESSION['targetID'];
        $postwall->setTargetID($targetID);
    }
    $postwall->setMyDisplayPreference($preference);
}

if (!empty($_SESSION['viewUser']))
{
	$user = $_SESSION['viewUser'];
    $postwall->setDisplayUser($user);
}

if (!empty($_SESSION['searchText']))
{
	$searchText = $_SESSION['searchText'];
    $postwall->setSearchText($searchText);
}

if (isset($_POST['postContent']) && isset($_POST['postTitle']) && isset($_POST['parentID']))
{
	$postTitle = $_POST['postTitle'];
    $postContent = $_POST['postContent'];
	$postParentID = $_POST['parentID'];
	$aPost = new Post($db, $userName, $postTitle, $postContent, $postParentID);
	$aPost->createPost($db);
	var_dump($aPost);
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}
else
{
	if (isset($_POST['postContent']) && isset($_POST['postTitle']))
	{
		$postTitle = $_POST['postTitle'];
		$postContent = $_POST['postContent'];
		$aPost = new Post($db, $userName, $postTitle, $postContent);
		$aPost->createPost($db);
		var_dump($aPost);
		$featurePage = $iniArray['pages']['feature'];
		header($featurePage);
	}
}

if (isset($_POST['editContent']) && isset($_POST['editTitle']) && isset($_POST['targetPostID']))
{
	$postTitle = $_POST['editTitle'];
    $postContent = $_POST['editContent'];
	$targetPostID = $_POST['targetPostID'];
	$targetPost = $postwall->findMyPost($targetPostID);

	$targetPost->editPost($postTitle, $postContent);
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}

if (isset($_POST['deletePostID']))
{

	$targetPostID = $_POST['deletePostID'];
	$targetPost = $postwall->findMyPost($targetPostID);
	$targetPost->deletePost();
	$featurePage = $iniArray['pages']['feature'];
	header($featurePage);
}

// if (isset($_POST['showOnePost']))
// {
	// $targetPostID = $_POST['showOnePost'];
	// $preference = "showOne";
	// $_SESSION["preference"] = $preference;
    // $_SESSION["targetID"] = $targetPostID;
	// header('Location: BaghChal_feature.php');
// }

?>
