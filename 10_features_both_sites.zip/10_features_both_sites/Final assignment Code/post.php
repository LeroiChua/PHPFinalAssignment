<?php

Class Post
{
	private $postID;
    private $userName;
    private $thePost;    
    private $title;
    private $date;
	private $parentID;
	private $childPosts = array();
	protected $db;
    
    public function __construct($db, $userName, $title, $content, $parentID = 0)
    {
        $this->postID = 0;
        $this->userName = $userName;
        $this->title = $title;
        $this->thePost = $content;
		$this->parentID = $parentID;
		$this->db = $db;
    }

    public function createPost($db)
    {
        // add the post to the post mysql_list_table
        $sql = "INSERT INTO post Values ('$this->postID', '$this->userName', '$this->title','$this->thePost', now(), '$this->parentID')";
        $result = $db->query($sql);
        return $result;
    }
    
    public function addComment($db, $postID, $userName)
    {
        // for the button
    }
	
	public function displayAllChildPosts()
	{
		$this->retrieveAllMyChildPosts();
		return $this->childPosts;
	}
	
	private function retrieveAllMyChildPosts()
	{
		$sql = "select * from post where parentID = " . $this->postID;
		$allMyChildPosts = $this->db->query($sql);
		$result = "";
		while ($aRow = $allMyChildPosts->fetch())
		{
            $postID = $aRow['postID'];
            $postTitle = $aRow['postTitle'];
            $userName = $aRow['userName'];
            $content = $aRow['content'];
            $date = $aRow['date'];
			$childPost = new Post($this->db, $userName, $postTitle, $content);
            $childPost->setID($postID);
            $childPost->setDate($date);		
			$this->childPosts[] = $childPost;
		}
	}
	
	public function editPost($postTitle, $postContent)
	{
		$sql = "update post set postTitle = '$postTitle', content = '$postContent' where postID = '$this->postID';";
		$result = $this->db->query($sql);
		
	}
    
    public function getPostID()
    {
        return $this->postID;
    }
    
    public function getUserName()
    {
        return $this->userName;
    }
    
    public function getContent()
    {
        return $this->thePost;
    }
    
    public function getTitle()
    {
        return $this->title;
    }
    
    public function getTheDate()
    {
        return $this->date;
    }
    
    public function setID($ID)
    {
        $this->postID = $ID;
    }
    
    public function setDate($date)
    {
        $this->date = $date;
    }
    
    public function deletePost()
    {
        $sql = "delete from post where postID = '$this->postID';";
        $result = $this->db->query($sql);
        return $result;
    }

}
?>
