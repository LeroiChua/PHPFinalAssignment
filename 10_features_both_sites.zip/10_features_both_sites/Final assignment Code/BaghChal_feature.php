<?php
// require_once("MySQLDB.php");
// require_once("db.php");

require_once("homeController.php");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Assignment 1</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/uikit.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="js/uikit.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="js/uikit-icons.min.js"></script>
</head>

<body>
    <div class="uk-container uk-container-small">
		<h1><?php
			echo "<p> Welcome ". $userName ."</p>"; 
		?></h1>	
        <nav class="uk-navbar-container" uk-navbar>
            <div class="uk-navbar-left">
                <ul class="uk-navbar-nav">
                    <li class="uk-active"><a href="home.html">Home</a></li>

                </ul>
            </div>		
        </nav>
        <div class="uk-width-medium-2-3">
            <h2 class="uk-panel-title">Bagchal Post</h2>
				<form type="hidden" action="homeController.php" method="POST">
					<button type="submit">View Post By Oldest</button>	
					<input type="hidden" name="preference" value="oldest"></input>	
				</form>
				<form type="hidden" action="homeController.php" method="POST">
					<button type="submit">View Post By Recent</button>	
					<input type="hidden" name="preference" value="recent"></input>	
				</form>

            <div class="uk-panel uk-panel-header">
                <form class='uk-form uk-form-stacked' action="homeController.php" method="POST">
                    <div class="uk-form-row">
                        <label class='uk-form-label'>Your post</label>
                        <div class="uk-form-controls">
                            <!-- PHP Posttitle -->
                            <input name="postTitle" class="uk-width-1-1" id="form-h-t" placeholder="Title of Post" cols="100"
                                rows="9"></input>
                        </div>                        
                        <div class="uk-form-controls">
                        <!-- PHP PostContent -->
                            <textarea name="postContent" class="uk-width-1-1" id="form-h-t" placeholder="What's on your mind?" cols="100"
                                rows="9"></textarea>
                        </div>
                    </div>
                    <div class="uk-form-row">
                        <div class="uk-form-controls">
                            <button type="submit" class="uk-button uk-button-primary">Post</button>
                        </div>
                    </div>
                </form>
                <!-- PHP POST WALL -->
				<?php foreach($postwall->displayMyPosts() as $aPost): ?>
					<div style='border: thin solid black'>
						<h1><?php echo "Post Title: " . $aPost->getTitle(); ?></h1>
					</div>
                    <div id="rootpost" type="visible" style='border: thin solid black'>
                        <p><?php echo $aPost->getContent();?></p>
                        <p><?php echo $aPost->getPostID(); ?></p>
                        <p><?php echo $aPost->getUserName();?></p> 
                        <p><?php echo $aPost->getTheDate();?></p>
                    </div>
                    <!-- PHP AddComment Section -->
                    <button data-toggle="collapse" data-target="#commentSection<?php echo $aPost->getPostID();?>">Add Comment</button>
                    <div id="commentSection<?php echo $aPost->getPostID();?>" class="collapse">
                        <form class="uk-form uk-form-stacked" action="homeController.php" method="POST">
                            <div class="uk-form-row">                      
                                <div class="uk-form-controls">
								<input name="postTitle" class="uk-width-1-1" id="form-h-t" placeholder="Title of Post" cols="100"
									rows="9"></input>
                                <!-- PHP commentContent -->
									<input type="hidden" name="parentID" value='<?php echo $aPost->getPostID();?>'</input>
                                    <textarea name="postContent" class="uk-width-1-1" id="form-h-t" placeholder="make a comment" cols="100"
                                        rows="9"></textarea>
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <div class="uk-form-controls">
                                    <button type="submit" class="uk-button uk-button-primary">Comment</button>
                                </div>
                            </div>
                        </form> 
                    </div>
					<!-- PHP AddComment Section END -->
					<!-- PHP ShowComments Section -->
                    <button data-toggle="collapse" data-target="#showcommentSection<?php echo $aPost->getPostID();?>">Show Comments</button>
                    <div id="showcommentSection<?php echo $aPost->getPostID();?>" class="collapse">
						<?php foreach ($aPost->displayAllChildPosts() as $aChildPost): ?>
							<div style='border: thin solid black'>
								<h1><?php echo "responding to Post Title: " . $aPost->getTitle();?></h1>
								<h1><?php echo $aChildPost->getTitle(); ?></h1>
								<br/>
								<p><?php echo $aChildPost->getContent();?></p>
								<p><?php echo $aChildPost->getPostID(); ?></p>
								<p><?php echo $aChildPost->getUserName();?></p> 
								<p><?php echo $aChildPost->getTheDate();?></p>								
							</div>
						<?php endforeach;?> 
                    </div>					
					<!-- PHP ShowComment Section END -->
					<!-- PHP EditPost Section -->					
                    <button data-toggle="collapse" data-target="#showEditSection<?php echo $aPost->getPostID();?>">Edit Post</button>
                    <div id="showEditSection<?php echo $aPost->getPostID();?>" class="collapse">
						<form style='border: thin solid black' action="homeController.php" method="POST">
							<div class="uk-form-controls">
								<input name="editTitle" class="uk-width-1-1" id="form-h-t" placeholder="Edit your post title" cols="100"
									rows="9"></input>
							</div>                        
							<div class="uk-form-controls">
								<textarea name="editContent" class="uk-width-1-1" id="form-h-t" placeholder="Edit your post content" cols="100"
									rows="9"></textarea>
							</div>
							<input type="hidden" name="targetPostID" value='<?php echo $aPost->getPostID();?>'></input>	
							<button type="submit" class="uk-button uk-button-primary">Save</button>							
						</form>						
                    </div>	
					<!-- PHP EditPost Section END -->
					<!-- PHP DeletePost Section -->
					
					<form type="hidden" action="homeController.php" method="POST">
						<button type="submit">Delete Post</button>	
						<input type="hidden" name="deletePostID" value='<?php echo $aPost->getPostID();?>'></input>	
					</form>
					<!-- PHP DeletePost Section END-->
					<!-- PHP Show target post Section-->

					<!-- PHP Show target post Section END-->					
                <?php endforeach;?>    
            </div>			
        </div>
</body>

</html>