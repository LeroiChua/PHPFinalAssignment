<?php
include_once 'MySQLDB.php';
require 'db.php';

//  create the database again
$db->createDatabase();
// select the database
$db->selectDatabase();

// drop the tables

$sql = "drop table if exists user";
$result = $db->query($sql);
//$sql = "drop table if exists post";
//$result = $db->query($sql);

// create the tables
$sql = "create table user (userID  integer not null auto_increment,
                                firstname varchar(30),
                                surname varchar(30),
								userName varchar(30),
                                password varchar(30),
                                primary key(userID)
								)ENGINE=InnoDB";

$result = $db->query($sql);

$sql = "create table if not exists post (postID  int not null auto_increment,
								userName varchar(30),
                                postTitle varchar(30),
                                content varchar(250),
                                date datetime,
								parentID int,
                                primary key(postID)
								)ENGINE=InnoDB";

$result = $db->query($sql);
$iniFile = $_SESSION['iniFile'];
echo $iniFile;

if($iniFile =="b.ini")
{
    $sql = "insert into user values (null, 'Frodo', 'Baggins', 'Frodo', 'a')";
    $result = $db->query($sql);
    $sql = "insert into user values (null, 'Samwise', 'Gamgee', 'Sam', 'a')";
    $result = $db->query($sql);
    $sql = "insert into user values (null, 'Gandalf', 'TheGrey', 'Gandalf', 'a')";
    $result = $db->query($sql);
}
if($iniFile == "h.ini")
{
    $sql = "insert into user values (null, 'Harry', 'Potter', 'Harry', 'a')";
    $result = $db->query($sql);
    $sql = "insert into user values (null, 'Ron', 'Weasley', 'Ron', 'a')";
    $result = $db->query($sql);
    $sql = "insert into user values (null, 'Hermione', 'Granger', 'Hermione', 'a')";
    $result = $db->query($sql);
}
?>
<html>
<body>

</body>
</html>
