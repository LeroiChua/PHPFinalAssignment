<?PHP
session_start();

unset($_SESSION['userName']);
unset($_SESSION['password']);
session_destroy();

header('location: start.html');
?>
