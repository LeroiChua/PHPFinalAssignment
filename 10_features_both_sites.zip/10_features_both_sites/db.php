<?php
session_save_path("./");
session_start();
$iniFile = $_SESSION['iniFile'];
$iniArray = parse_ini_file("$iniFile", true);


$host = 'localhost' ;
$dbUser ='root';
$dbPass ='';
$dbName = $iniArray['connection']['dbName'];

$db = new MySQL( $host, $dbUser, $dbPass, $dbName ) ;
$db->selectDatabase();
?>
